//
//  TableImageViewCell.swift
//  ILABankDemo
//
//  Created by Neosoft on 29/01/23.
//

import UIKit

protocol ImageCellDelegate: AnyObject {
    func suffleList(index: Int)
}

class TableImageViewCell: UITableViewCell {
    @IBOutlet weak var imageCollectionView: UICollectionView!
    @IBOutlet weak var pageControl: UIPageControl!
    var delegate:ImageCellDelegate?
    
    var contentList:[DataModel]?{
        didSet{
            self.updateCell()
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.setupUI()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    
    func setupUI(){
        imageCollectionView.register(UINib(nibName: Constants.image_Collection_View_cell, bundle: nil), forCellWithReuseIdentifier: Constants.image_Collection_View_cell)
        imageCollectionView.dataSource = self
        imageCollectionView.delegate = self
    }
    
    func updateCell(){
        pageControl.numberOfPages = contentList?.count ?? 0
        imageCollectionView.reloadData()
    }
        
}


extension TableImageViewCell:UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: Constants.image_Collection_View_cell, for: indexPath) as! ImageCollectionViewCell
        cell.data = contentList?[indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return contentList?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize.init(width: self.imageCollectionView.frame.width, height: self.imageCollectionView.frame.height)
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        if !scrollView.isPagingEnabled { return }
        let index = Int(scrollView.contentOffset.x) / Int(scrollView.frame.width)
        pageControl?.currentPage = index
        delegate?.suffleList(index: index)
    }
    
}
