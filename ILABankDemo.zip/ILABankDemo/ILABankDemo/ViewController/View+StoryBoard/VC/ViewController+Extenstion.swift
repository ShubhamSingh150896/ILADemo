//
//  ViewController+Extenstion.swift
//  ILABankDemo
//
//  Created by Neosoft on 29/01/23.
//

import UIKit

extension ViewController: UITableViewDataSource,UITableViewDelegate{
    
    func numberOfSections(in tableView: UITableView) -> Int {
        2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 { return 1 }
        return viewModel.getListCount()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0{
            let cell = tableView.dequeueReusableCell(withIdentifier: Constants.table_Image_View_cell, for: indexPath) as? TableImageViewCell
            cell?.contentList = viewModel.contentList
            cell?.delegate = self
            return cell!
        }else{
            let cell = tableView.dequeueReusableCell(withIdentifier: Constants.table_View_cell, for: indexPath) as? TableViewCell
            cell?.data = viewModel.getIndexModel(index: indexPath.row)
            return cell!
        }
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        if section == 0 { return nil }
        if  let view = Bundle.main.loadNibNamed(Constants.search_View, owner: nil, options: nil)?.first as? SearchView{
            view.searchBar.delegate = self
            return view
        }
        return nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section == 0 { return 0 }
        return 50
    }
    
}

//MARK: - UISearchBarDelegate
extension ViewController:UISearchBarDelegate{
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        self.view.endEditing(true)
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        viewModel.searchList(searchText: searchText)
        reloadTableView()
    }
}

extension ViewController: ImageCellDelegate{
    func suffleList(index: Int) {
        viewModel.searchActive = false
        self.viewModel.contentList.shuffle()
        reloadTableView()
    }
}
