//
//  ViewController.swift
//  ILABankDemo
//
//  Created by Neosoft on 29/01/23.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var listTableView: UITableView!
    let viewModel = ViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setupObserver()
    }
    
    func setupObserver(){
        viewModel.getLocalDataList(completion: { reload in
            if reload{
                self.reloadTableView()
            }
        })
    }
    
    //MARK: - Setup UI & Registering View
    func setupUI(){
        listTableView.register(UINib(nibName: Constants.table_Image_View_cell, bundle: nil), forCellReuseIdentifier: Constants.table_Image_View_cell)
        listTableView.register(UINib(nibName: Constants.table_View_cell, bundle: nil), forCellReuseIdentifier: Constants.table_View_cell)
        if #available(iOS 15.0, *) {
            listTableView.sectionHeaderTopPadding = 0
        }
    }
    
    func reloadTableView() {
        DispatchQueue.main.async {
            self.listTableView.reloadData()
        }
    }
    
}



