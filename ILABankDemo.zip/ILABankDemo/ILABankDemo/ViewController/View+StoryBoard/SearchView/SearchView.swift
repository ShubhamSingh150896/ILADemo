//
//  SearchView.swift
//  ILABankDemo
//
//  Created by Neosoft on 29/01/23.
//

import UIKit

class SearchView: UIView {
    @IBOutlet weak var searchBar: UISearchBar!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
    }

}
