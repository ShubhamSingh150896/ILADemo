//
//  ViewModel.swift
//  ILABankDemo
//
//  Created by Neosoft on 29/01/23.
//

import Foundation


class ViewModel: NSObject {
    var contentList:[DataModel] = []
    var filteredList:[DataModel] = []
    var searchActive: Bool = false
    
    //MARK:- Filter
    func searchList(searchText: String) {
        if searchText == "" {
            self.searchActive = false
        } else {
            self.searchActive = true
            filteredList = self.contentList.filter({(($0.title.localizedCaseInsensitiveContains(searchText)))})
        }
    }
    
    //MARK:- Get list count
    func getListCount() -> Int {
        if !self.searchActive {
            return contentList.count
        } else {
            return filteredList.count
        }
    }
    
    func getIndexModel(index: Int) -> DataModel? {
        if !self.searchActive {
            return contentList[index]
        } else {
            return filteredList[index]
        }
    }
    
    func getLocalDataList(completion: @escaping (_ reload: Bool) -> Void) {
        do {
            if let bundlePath = Bundle.main.path(forResource: "Content",ofType: "json"),
               let jsonData = try String(contentsOfFile: bundlePath).data(using: .utf8) {
                let homeData = try JSONDecoder().decode([DataModel].self,from: jsonData)
                contentList = homeData
                completion(true)
            }
        } catch {
            completion(false)
            print(error)
        }
    }
}
